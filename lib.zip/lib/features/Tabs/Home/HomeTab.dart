import 'package:flutter/material.dart';
import 'package:movies/core/resources/assets_manger.dart';
import 'package:movies/core/resources/colors_manger.dart';

import 'Widgets/Category_card.dart';
import 'Widgets/Movie_Model.dart';
import 'Widgets/Movies_Data.dart';
import 'Widgets/Top_section.dart';

// ─── Home Screen ──────────────────────────────────────────────────────────────

class Hometab extends StatefulWidget {
  const Hometab({super.key}); // ✅ const, no mutable fields here

  @override
  State<Hometab> createState() => _HometabState();
}

class _HometabState extends State<Hometab> with SingleTickerProviderStateMixin {

  // ✅ ALL state lives here, not in the widget
  int activeIndex = 0;
  String currentBg = featuredMovies[0].poster_image;
  String prevBg = featuredMovies[0].poster_image;
  bool bgVisible = true;

  // ✅ late final initializes before build, uses vsync from this State
  late final AnimationController bgAnimController = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 700),
  );

  late final Animation<double> bgFadeAnim = CurvedAnimation(
    parent: bgAnimController,
    curve: Curves.easeInOut,
  );

  final PageController pageController = PageController(
    viewportFraction: 0.62,
    initialPage: 0,
  );

  @override
  void dispose() {
    pageController.dispose();
    bgAnimController.dispose();
    super.dispose();
  }

  void _onPageChanged(int index) {
    final newBg = featuredMovies[index].poster_image;
    setState(() {
      prevBg = currentBg;
      activeIndex = index;
      currentBg = newBg;
    });
    bgAnimController.reset();
    bgAnimController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorsManger.black,
      body: Stack(
        children: [
          // ── Blurred background ──────────────────────────────────────────
          _BlurredBackground(
            prevUrl: prevBg,
            currentUrl: currentBg,
            animation: bgFadeAnim,
          ),

          // ── Dark gradient overlay ───────────────────────────────────────
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0x44000000),
                  Color(0x22000000),
                  Color(0x99000000),
                  Color(0xF2000000),
                ],
                stops: [0.0, 0.3, 0.65, 1.0],
              ),
            ),
          ),

          // ── Scrollable content ──────────────────────────────────────────
          CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: TopSection(
                  activeIndex: activeIndex,
                  currentBg: currentBg,
                  bgAnimController: bgAnimController,
                  bgFadeAnim: bgFadeAnim,
                  bgVisible: bgVisible,
                  prevBg: prevBg,
                  onPageChanged: _onPageChanged,
                ),
              ),
              SliverToBoxAdapter(
                child: Image.asset(AssetsManger.available),
              ),
              ..._buildCategorySliders(),
              const SliverToBoxAdapter(child: SizedBox(height: 40)),
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _buildCategorySliders() {
    return categories.entries.map((entry) {
      return SliverToBoxAdapter(
        child: _CategoryRow(
          label: entry.key,
          movies: entry.value,
        ),
      );
    }).toList();
  }
}

// ─── Blurred Background ───────────────────────────────────────────────────────

class _BlurredBackground extends StatelessWidget {
  final String prevUrl;
  final String currentUrl;
  final Animation<double> animation;

  const _BlurredBackground({
    required this.prevUrl,
    required this.currentUrl,
    required this.animation,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        _buildBgImage(prevUrl),
        FadeTransition(
          opacity: animation,
          child: _buildBgImage(currentUrl),
        ),
      ],
    );
  }

  Widget _buildBgImage(String url) {
    return Image.network(
      url,
      fit: BoxFit.cover,
      color: Colors.black.withOpacity(0.78),
      colorBlendMode: BlendMode.darken,
      errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF0a0a0f)),
    );
  }
}

// ─── Category Row ─────────────────────────────────────────────────────────────

class _CategoryRow extends StatelessWidget {
  final String label;
  final List<MovieModel> movies;

  const _CategoryRow({required this.label, required this.movies});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Text(
                  'See More →',
                  style: TextStyle(
                    color: Color(0xFFF5C518),
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          SizedBox(
            height: 200,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: movies.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (context, index) {
                return CategoryCard(
                  dominantColor: movies[index].dominantColor,
                  rating: movies[index].rating,
                  poster_image: movies[index].poster_image,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}