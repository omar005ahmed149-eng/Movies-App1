import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:movies/features/Tabs/Home/HomeTab.dart';

import '../../../../core/resources/assets_manger.dart';
import 'Movie_Model.dart';
import 'Movies_Data.dart';
import 'Rating_Badge.dart';

class TopSection extends StatelessWidget {
   TopSection({required this.activeIndex,
     required this.currentBg,
     required this.bgAnimController,
     required this.bgFadeAnim,
     required this.bgVisible,
     required this.prevBg,
     required this.onPageChanged});
  int activeIndex;
  String currentBg ;
  String prevBg ;
  bool bgVisible ;

  final PageController pageController = PageController(
    viewportFraction: 0.62,
    initialPage: 0,
  );
   final ValueChanged<int> onPageChanged ;

  late AnimationController bgAnimController;
  late Animation<double> bgFadeAnim;
  @override
  Widget build(BuildContext context) {
    return  Column(
        children: [
          const SizedBox(height: 56),

          Image.asset(AssetsManger.available),

          const SizedBox(height: 16),

          SizedBox(
            height: 360,
            child: PageView.builder(
              controller: PageController(),
              itemCount: featuredMovies.length,
              onPageChanged: onPageChanged,
              itemBuilder: (context, index) {
                return _HeroCard(
                  movie: featuredMovies[index],
                  isActive: index == activeIndex,
                );
              },
            ),
          ),
           SizedBox(height: 28.h),
        ],
    );
  }

}

class _HeroCard extends StatelessWidget {
  final MovieModel movie;
  final bool isActive;

  const _HeroCard({required this.movie, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return AnimatedScale(
      scale: isActive ? 1.0 : 0.88,
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOutBack,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Poster
              Image.asset(
                movie.poster_image,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    ColoredBox(color: movie.dominantColor),
              ),

              // Bottom gradient + tagline (active only)
              if (isActive)
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(14, 40, 14, 14),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Color(0xCC000000)],
                      ),
                    ),
                    child: Text(
                      movie.tagline,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 10,
                        letterSpacing: 3,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),

              // Rating badge
              Positioned(
                top: 10,
                left: 10,
                child: RatingBadge(rating: movie.rating),
              ),
            ],
          ),
        ),
      ),
    );
  }
}



